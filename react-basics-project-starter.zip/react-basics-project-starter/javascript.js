document.getElementById("footerbuttonRecipe").click(function () {
  document.getElementsByClassName("recipepage").style.display = "block";
  document.getElementsByClassName("aboutpage").style.display = "none";
});
document.getElementById("footerbuttonAbout").click(function () {
  document.getElementsByClassName("recipepage").style.display = "none";
  document.getElementsByClassName("aboutpage").style.display = "block";
});
