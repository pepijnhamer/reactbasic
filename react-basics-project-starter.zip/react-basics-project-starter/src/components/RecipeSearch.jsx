import { useState } from "react";
import { data } from "../utils/data";
import { RecipeList } from "./RecipeList";
import { TextInput } from "./ui/TextInput";

export const RecipeSearch = ({ clickFn }) => {
  const [searchField, setSearchField] = useState("test recipe");

  return (
    <>
      <label>Search for recipes:</label>
      <TextInput />
      <RecipeList clickFn={clickFn} recipes={data} />
    </>
  );
};
