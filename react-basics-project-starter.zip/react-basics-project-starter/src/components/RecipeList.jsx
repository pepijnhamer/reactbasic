import { RecipeItem } from "./RecipeItem";

export const RecipeList = ({ recipes, clickFn }) => {
  return (
    <>
      {recipes.map((recipe) => (
        <RecipeItem key={recipe.id} recipe={recipe} clickFn={clickFn} />
      ))}
    </>
  );
};
