import "./RecipeItem.css";

export const RecipeItem = ({ recipe, clickFn }) => {
  return (
    <button className="recipe-item" onClick={() => clickFn(recipe)}>
      <img src={recipe.imgUrl} width={50} height={50} alt={recipe.alt} />
      <p>{recipe.label}</p>
    </button>
  );
};
