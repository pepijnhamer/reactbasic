import { useState } from "react";
import "./App.css";
import { RecipeChoice } from "./components/RecipeChoice";
import { RecipeSearch } from "./components/RecipeSearch";

export const App = () => {
  const [userRecipe, setUserRecipe] = useState();

  const searchMessage = "Find a recipe";

  return (
    <div className="App">
      {userRecipe ? (
        <RecipeChoice recipe={userRecipe} clickFn={setUserRecipe} />
      ) : (
        <>
          <h1>{searchMessage}</h1>
          <RecipeSearch clickFn={setUserRecipe} />
        </>
      )}
    </div>
  );
};
